#set -x

IFS=$'\n'
for i in `ls *png`
do
	td=`echo $i|awk -F '.' '{print "sample/"$2"/"$3}'`
	mkdir -p $td
	mv $i $td
done
